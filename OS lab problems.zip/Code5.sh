echo "Enter the filename"
read file
v=0
exec 3<&0
while read -n 1 c
do
l="$(echo $c | tr '[A-Z]' '[a-z]')"
[ "$l" == "a" -o "$l" == "e" -o "$l" == "i" -o "$l" == "o" -o "$l" == "u" ] && (( v++ )) || :
done < $file
echo "Vowels : $v"
echo "Characters : $(cat $file | wc -c)"
echo "Blank lines : $(grep -c '^$' $file)"
echo "Lines : $(cat $file|wc -l )"
