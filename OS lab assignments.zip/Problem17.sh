#!/bin/bash

read -p " Please enter the directory you want to count its files & subdirectories = " path

echo "Number of directories in $path =  "$(find $path/* -type d | wc -l)

echo "Number of Files in $path = "$(find $path/* -type f | wc -l)
