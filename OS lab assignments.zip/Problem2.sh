echo "Enter string"
read str
 
length=`echo $str | wc -c`
length=`echo $length - 1 |bc`
if [ $length -lt 5 ]
then
echo "You have entered less than 5 characters"
else
echo "The string have more than 5 char"
fi