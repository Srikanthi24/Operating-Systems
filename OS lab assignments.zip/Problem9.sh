echo "Enter the filename : "
read file
if [ -f $file ]
then
aspell check $file
else
echo "The file doesn't exist"
fi
