#!/bin/bash
 
for i in {1..3}
 
do
 
echo -n "This is a test in loop $i ";date
 
sleep 30
 
done
