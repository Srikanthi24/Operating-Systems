out="output.$$"
echo -n "Emter the file name : "
read file
if [ ! -f $file ]
then
echo "File doesn't exist"
exit 1
fi
sed -e 's/[\t ]//g;/^$/d' $file > $out
echo "Output written to $out file"