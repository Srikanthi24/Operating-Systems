echo "enter the file name"
counter=0
if [ ! -f $file ]
echo "$file not a file!"
fi
do
isEvenNo=$( expr $counter % 2 )
then
echo $line >> $out
# increase counter by 1
done < $file
/bin/rm -f $file
/bin/mv $out $file
