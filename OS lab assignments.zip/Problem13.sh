read -p "Give a first file name : " First
read -p "Give a second file name : " Second
read -p "Give a third file name : " Third
cat $First $Second $Third >> combined
cat combined | more
wc - w combined
