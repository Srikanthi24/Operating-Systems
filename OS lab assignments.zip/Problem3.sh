#!/bin/bash
 
read -p "Enter a string:" str
 
length=${#str}
 
echo "Length of '$str' is $length"
